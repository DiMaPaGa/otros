export interface WorkExperienceProps {
    title: string;
    items: Array<{
      jobTitle: string;
      company: string;
      years: string;
      description: string;
    }>;
  }
  