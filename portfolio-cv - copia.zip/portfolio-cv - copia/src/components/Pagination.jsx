import React from 'react';
import PropTypes from 'prop-types'; // Importamos PropTypes

const Pagination = ({ currentPage, totalPages }) => {
  const goToPage = (newPage) => {
    console.log(`Intentando cambiar a la página: ${newPage}`); // Verificamos el nuevo número de página

    // Cambiamos la URL
    window.history.pushState({}, '', `?page=${newPage}`);
    console.log('URL después del cambio:', window.location.href);

    // Nuevo mensaje para confirmar que el evento se dispara
  console.log('Evento disparado desde el botón Siguiente');
  };

  return (
    <div className="flex justify-between items-center mt-6">
      <button
        className={`px-4 py-2 bg-blue-500 text-white rounded-md hover:bg-blue-600 transition ${
          currentPage === 0 ? 'opacity-50 cursor-not-allowed' : ''
        }`}
        disabled={currentPage === 0}
        onClick={() => {
          console.log("Botón 'Anterior' clicado"); // Para depurar
          goToPage(currentPage - 1);
        }}
      >
        Anterior
      </button>

      <button
        className={`px-4 py-2 bg-blue-500 text-white rounded-md hover:bg-blue-600 transition ${
          currentPage === totalPages - 1 ? 'opacity-50 cursor-not-allowed' : ''
        }`}
        disabled={currentPage === totalPages - 1}
        onClick={() => {
          console.log("Botón 'Siguiente' clicado"); // Para depurar
          goToPage(currentPage + 1);
        }}
      >
        Siguiente
      </button>
    </div>
  );
};

// Validación de los props
Pagination.propTypes = {
  currentPage: PropTypes.number.isRequired, // Debe ser un número
  totalPages: PropTypes.number.isRequired,  // Debe ser un número
};

export default Pagination;
