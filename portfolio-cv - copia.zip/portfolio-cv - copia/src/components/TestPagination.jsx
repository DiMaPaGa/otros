import React from 'react';

const TestPagination = () => {
  return (
    <div>
      <button
        onClick={() => console.log("Botón de prueba clicado")}
        className="px-4 py-2 bg-green-500 text-white rounded-md"
      >
        Botón de prueba
      </button>
    </div>
  );
};

export default TestPagination;
